#ifndef LED_CONTROLLER_H_
#define LED_CONTROLLER_H_

void initLEDs(void);
void ledc_init(void);
void led_set(void);

#endif /* LED_CONTROLLER_H_ */