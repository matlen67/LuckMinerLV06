#ifndef USER_INPUT_TASK_H_
#define USER_INPUT_TASK_H_

void USER_INPUT_task(void *pvParameters);

#endif