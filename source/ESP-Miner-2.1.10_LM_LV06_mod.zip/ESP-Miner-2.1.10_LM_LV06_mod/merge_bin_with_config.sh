#!/bin/bash

./merge_bin.sh -c $1
